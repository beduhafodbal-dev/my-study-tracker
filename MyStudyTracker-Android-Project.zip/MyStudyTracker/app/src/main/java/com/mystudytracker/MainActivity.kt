package com.mystudytracker

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters
import java.util.Locale

private val Bg = Color(0xFF080D18)
private val Panel = Color(0xFF111B2D)
private val Blue = Color(0xFF398BFF)
private val Muted = Color(0xFF9AAAC2)
private val subjects = listOf("Математика", "Азербайджанский", "Английский", "Физика", "Информатика")
private val days = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TrackerApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackerApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("tracker", Context.MODE_PRIVATE) }
    val today = LocalDate.now()
    val monday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
    var selectedDay by remember { mutableIntStateOf((today.dayOfWeek.value - 1).coerceIn(0, 6)) }
    var refresh by remember { mutableIntStateOf(0) }
    var selectedSubject by remember { mutableStateOf(subjects.first()) }
    var hoursInput by remember { mutableStateOf("") }
    var minsInput by remember { mutableStateOf("") }
    var timerSubject by remember { mutableStateOf(subjects.first()) }
    var running by remember { mutableStateOf(prefs.getBoolean("timer_running", false)) }
    var startedAt by remember { mutableLongStateOf(prefs.getLong("timer_started", 0L)) }
    var elapsedBefore by remember { mutableLongStateOf(prefs.getLong("timer_elapsed", 0L)) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var tab by remember { mutableIntStateOf(0) }
    var goal by remember { mutableIntStateOf(prefs.getInt("weekly_goal", 30)) }
    LaunchedEffect(running) { while (running) { now = System.currentTimeMillis(); delay(1000) } }

    fun key(date: LocalDate, subject: String) = "${date}|${subject}"
    fun minutes(date: LocalDate, subject: String): Int = prefs.getInt(key(date, subject), 0)
    fun addMinutes(date: LocalDate, subject: String, amount: Int) {
        prefs.edit().putInt(key(date, subject), minutes(date, subject) + amount).apply()
        refresh++
    }
    val weekDates = (0..6).map { monday.plusDays(it.toLong()) }
    val totals = subjects.associateWith { s -> weekDates.sumOf { minutes(it, s) } }
    val total = totals.values.sum() + (refresh * 0)
    val timerMs = elapsedBefore + if (running) (now - startedAt).coerceAtLeast(0) else 0L
    val timerText = String.format(Locale.getDefault(), "%02d:%02d:%02d", timerMs / 3600000, (timerMs / 60000) % 60, (timerMs / 1000) % 60)

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.BarChart, null) }, label = { Text("Неделя") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Timer, null) }, label = { Text("Таймер") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.EditNote, null) }, label = { Text("Добавить") })
            }
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item { Spacer(Modifier.height(8.dp)); Text("MY STUDY TRACKER", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Text("ТВОЙ ПРОГРЕСС • ${monday} — ${monday.plusDays(6)}", color = Muted, fontSize = 10.sp) }
                if (tab == 0) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                Text("ВСЕГО ЗА НЕДЕЛЮ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("${total / 60} ч ${total % 60} мин", color = Blue, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                LinearProgressIndicator(progress = { (total.toFloat() / (goal * 60).coerceAtLeast(1)).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Blue, trackColor = Color(0xFF26354D))
                                Spacer(Modifier.height(6.dp)); Text("Цель: $goal ч • ${(total * 100 / (goal * 60).coerceAtLeast(1)).coerceAtMost(100)}%", color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                    item { Text("ПРЕДМЕТЫ", color = Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    items(subjects) { s ->
                        val m = totals[s] ?: 0
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) { Text(s, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text("${m / 60} ч ${m % 60} мин", color = Blue, fontWeight = FontWeight.Bold) }
                                Spacer(Modifier.height(9.dp)); LinearProgressIndicator(progress = { (m / 600f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp), color = Blue, trackColor = Color(0xFF26354D))
                            }
                        }
                    }
                    item { Text("ПО ДНЯМ", color = Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) { days.forEachIndexed { i, d -> Column(Modifier.weight(1f).background(if (i == selectedDay) Blue.copy(alpha = .22f) else Panel, RoundedCornerShape(12.dp)).clickable { selectedDay = i }.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(d, color = if (i == selectedDay) Blue else Muted, fontWeight = FontWeight.Bold); Text("${weekDates[i].dayOfMonth}", color = Color.White) } } } }
                    item { Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp)) { Text("${days[selectedDay]} • ${weekDates[selectedDay]}", fontWeight = FontWeight.Bold); subjects.forEach { s -> val m = minutes(weekDates[selectedDay], s); Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(s, color = Muted); Text("${m / 60} ч ${m % 60} мин") } } } }
                    item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Недельная цель", Modifier.weight(1f), color = Muted); OutlinedButton(onClick = { goal = (goal - 1).coerceAtLeast(1); prefs.edit().putInt("weekly_goal", goal).apply() }) { Text("−") }; Text(" $goal ч "); OutlinedButton(onClick = { goal++; prefs.edit().putInt("weekly_goal", goal).apply() }) { Text("+") } } }
                } else if (tab == 1) {
                    item { Text("ТАЙМЕР ЗАНЯТИЙ", color = Muted, fontWeight = FontWeight.Bold) }
                    item { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) { Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(timerText, color = Blue, fontSize = 42.sp, fontWeight = FontWeight.Bold); Text(if (running) "Идёт занятие" else "Таймер остановлен", color = Muted); Spacer(Modifier.height(18.dp)); SubjectPicker(timerSubject) { timerSubject = it }; Spacer(Modifier.height(16.dp)); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { Button(onClick = { if (!running) { startedAt = System.currentTimeMillis(); running = true; prefs.edit().putBoolean("timer_running", true).putLong("timer_started", startedAt).apply() } else { elapsedBefore += (System.currentTimeMillis() - startedAt).coerceAtLeast(0); running = false; prefs.edit().putBoolean("timer_running", false).putLong("timer_elapsed", elapsedBefore).apply() } }) { Icon(if (running) Icons.Default.Pause else Icons.Default.PlayArrow, null); Text(if (running) "Пауза" else "Старт") }; OutlinedButton(onClick = { val finalMs = elapsedBefore + if (running) (System.currentTimeMillis() - startedAt).coerceAtLeast(0) else 0L; val mins = (finalMs / 60000).toInt(); if (mins > 0) addMinutes(today, timerSubject, mins); running = false; elapsedBefore = 0; startedAt = 0; prefs.edit().putBoolean("timer_running", false).putLong("timer_elapsed", 0).putLong("timer_started", 0).apply(); now = System.currentTimeMillis() }) { Icon(Icons.Default.Stop, null); Text("Завершить") } } } } }
                    item { Text("Таймер можно поставить на паузу и продолжить позже. При завершении полные минуты добавятся в сегодняшний учёт.", color = Muted, fontSize = 12.sp) }
                } else {
                    item { Text("ДОБАВИТЬ ВРЕМЯ ВРУЧНУЮ", color = Muted, fontWeight = FontWeight.Bold) }
                    item { SubjectPicker(selectedSubject) { selectedSubject = it } }
                    item { Text("День: ${today}", color = Muted) }
                    item { OutlinedTextField(value = hoursInput, onValueChange = { hoursInput = it.filter(Char::isDigit).take(3) }, label = { Text("Часы") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(value = minsInput, onValueChange = { minsInput = it.filter(Char::isDigit).take(2) }, label = { Text("Минуты") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()) }
                    item { Button(onClick = { val amount = (hoursInput.toIntOrNull() ?: 0) * 60 + (minsInput.toIntOrNull() ?: 0); if (amount > 0) { addMinutes(today, selectedSubject, amount); hoursInput = ""; minsInput = "" } }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить время") } }
                    item { Text("Время записывается на сегодняшний день. Для прошлых дней можно выбрать день на вкладке «Неделя» — редактирование прошлых записей добавим в следующей версии.", color = Muted, fontSize = 12.sp) }
                }
                item { Spacer(Modifier.height(12.dp)); Text("Данные хранятся локально на этом устройстве.", color = Muted, fontSize = 10.sp) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubjectPicker(value: String, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(value = value, onValueChange = {}, readOnly = true, label = { Text("Предмет") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { subjects.forEach { s -> DropdownMenuItem(text = { Text(s) }, onClick = { onSelect(s); expanded = false }) } }
    }
}
